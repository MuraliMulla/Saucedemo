package com.reskill.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CheckoutPageLocators {

static Logger logger = LogManager.getLogger(CheckoutPageLocators.class);
	
	public Properties readProductPropertiesFile() {
		
		FileInputStream prodlocator = null;
		Properties pordProperties = null;
		try {
			prodlocator = new FileInputStream("src/main/java/com/reskill/locators/checkout.properties");
			pordProperties = new Properties();
			pordProperties.load(prodlocator);
		} catch (FileNotFoundException e) {
			logger.error("File Not Found");
		} catch (IOException e) {
			logger.error("IOException");
		}
		return pordProperties;
	}
	
	public String getCheckoutHeader() {
		return readProductPropertiesFile().getProperty("checkoutHeader");
	}
	public String getCheckoutFirstName() {
		return readProductPropertiesFile().getProperty("checkoutFirstName");
	}
	public String checkoutLastName() {
		return readProductPropertiesFile().getProperty("checkoutLastName");
	}
	public String getcheckoutzip() {
		return readProductPropertiesFile().getProperty("checkoutzip");
	}
	public String getcheckoutContinue() {
		return readProductPropertiesFile().getProperty("checkoutContinue");
	}
	public String getcheckoutCancel() {
		return readProductPropertiesFile().getProperty("checkoutCancel");
	}
	public String getCheckoutFnameLabel() {
		return readProductPropertiesFile().getProperty("checkoutFnameLabel");
	}
	public String getcheckoutLnameLabel() {
		return readProductPropertiesFile().getProperty("checkoutLnameLabel");
	}
	public String getcheckoutZipLabel() {
		return readProductPropertiesFile().getProperty("checkoutZipLabel");
	}
}

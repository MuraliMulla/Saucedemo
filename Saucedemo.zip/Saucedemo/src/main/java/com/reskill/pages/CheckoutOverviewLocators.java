package com.reskill.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CheckoutOverviewLocators {

	
static Logger logger = LogManager.getLogger(CheckoutOverviewLocators.class);
	
	public Properties readProductPropertiesFile() {
		
		FileInputStream prodlocator = null;
		Properties pordProperties = null;
		try {
			prodlocator = new FileInputStream("src/main/java/com/reskill/locators/checkoutOverview.properties");
			pordProperties = new Properties();
			pordProperties.load(prodlocator);
		} catch (FileNotFoundException e) {
			logger.error("File Not Found");
		} catch (IOException e) {
			logger.error("IOException");
		}
		return pordProperties;
	}
	
	public String getCheckoutOverviewTitle() {
		return readProductPropertiesFile().getProperty("checkoutOverviewTitle");
	}
	public String getCheckoutPaymentInfo() {
		return readProductPropertiesFile().getProperty("checkoutPaymentInfo");
	}
	public String getCheckoutSauceCard() {
		return readProductPropertiesFile().getProperty("checkoutSauceCard");
	}
	public String getCheckoutShippingInfo() {
		return readProductPropertiesFile().getProperty("checkoutShippingInfo");
	}
	public String getCheckoutShippingDeliver() {
		return readProductPropertiesFile().getProperty("checkoutShippingDeliver");	
	}
	public String getChcekoutItemTotal() {
		return readProductPropertiesFile().getProperty("chcekoutItemTotal");
	}
	public String getCheckoutTax() {
		return readProductPropertiesFile().getProperty("checkoutTax");
	}
	public String getCheckoutTotal() {
		return readProductPropertiesFile().getProperty("checkoutTotal");
	}
	public String getCheckoutCancel() {
		return readProductPropertiesFile().getProperty("checkoutCancel");
	}
	public String getCheckoutFinish() {
		return readProductPropertiesFile().getProperty("checkoutFinish");
	}
	public String getCheckoutCancelLabel() {
		return readProductPropertiesFile().getProperty("checkoutCancelLabel");
	}
	public String getCheckoutFinishLabel() {
		return readProductPropertiesFile().getProperty("checkoutFinishLabel");
	}
}

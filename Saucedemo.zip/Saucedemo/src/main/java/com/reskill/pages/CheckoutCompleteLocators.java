package com.reskill.pages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CheckoutCompleteLocators {
	
	static Logger logger = LogManager.getLogger(CheckoutCompleteLocators.class);


public Properties readProductPropertiesFile() {
		
		FileInputStream prodlocator = null;
		Properties pordProperties = null;
		try {
			prodlocator = new FileInputStream("src/main/java/com/reskill/locators/checkoutComplete.properties");
			pordProperties = new Properties();
			pordProperties.load(prodlocator);
		} catch (FileNotFoundException e) {
			logger.error("File Not Found");
		} catch (IOException e) {
			logger.error("IOException");
		}
		return pordProperties;
	}
	
	public String getCheckoutComplete() {
		return readProductPropertiesFile().getProperty("checkoutComplete");
	}
	
	public String getCompleteHeaderText() {
		return readProductPropertiesFile().getProperty("completeHeaderText");
	}
	
	public String getOrderDiscription() {
		return readProductPropertiesFile().getProperty("orderDiscription");
	}
	
	public String getponnyExpressLogo() {
		return readProductPropertiesFile().getProperty("ponnyExpressLogo");
	}
	
	public String getBackHomeButton() {
		return readProductPropertiesFile().getProperty("backHomeButton");
	}
	
	public String getPonyExpressLogoLabel() {
		return readProductPropertiesFile().getProperty("ponyExpressLogoLabel");
	}
	
	
	
}

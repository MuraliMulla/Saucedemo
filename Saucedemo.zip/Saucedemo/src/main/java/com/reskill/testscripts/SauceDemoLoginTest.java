package com.reskill.testscripts;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.reskill.actions.CheckButtonAction;
import com.reskill.actions.CheckElement;
import com.reskill.actions.CheckItemTotal;
import com.reskill.actions.CheckTextField;
import com.reskill.actions.ExcelDataReads;
import com.reskill.actions.LoginDetails;
import com.reskill.actionutility.SelectWebDriver;
import com.reskill.pages.CartPageLocators;
import com.reskill.pages.CheckoutCompleteLocators;
import com.reskill.pages.CheckoutOverviewLocators;
import com.reskill.pages.CheckoutPageLocators;
import com.reskill.pages.ProductPageLocators;
import com.reskill.pages.UserLoginPageLocators;

public class SauceDemoLoginTest extends LoginDetails {
	
	LoginDetails loginName = new LoginDetails();
			
	static Logger logger = Logger.getLogger(SauceDemoLoginTest.class);

	SelectWebDriver requestDriver = new SelectWebDriver();

	CheckElement elementCheck = new CheckElement();

	UserLoginPageLocators userLoginPage = new UserLoginPageLocators();
	
	ProductPageLocators productPage = new ProductPageLocators();
	
	CartPageLocators cartPage = new CartPageLocators();

	CheckTextField textFiledCheck = new CheckTextField();
	
	CheckoutPageLocators checkout = new CheckoutPageLocators();

	CheckButtonAction buttonCheck = new CheckButtonAction();
	
	CheckoutOverviewLocators checkOverview = new CheckoutOverviewLocators();
	
	CheckItemTotal checkItemTotal = new CheckItemTotal();
	
	CheckoutCompleteLocators complete = new CheckoutCompleteLocators();
	
	ExcelDataReads readxlData = new ExcelDataReads();
	
	
	public WebDriver driver;

	@BeforeTest
	public void selectBrowser() {
		driver = requestDriver.getDriver();
		requestDriver.getUrl(driver);
	}

//	@Test
//	public void CheckUserNamesandPasswordTextPresent() {
//		
//		String acceptedUsernamesText = "Accepted usernames are:";
//		String standardUserText = "standard_user";
//		String lockedOutUserText = "locked_out_user";
//		String problemUserText = "problem_user";
//		String performanceGlitchUserText = "performance_glitch_user";
//		String passwordforallusersText = "Password for all users:";
//		String secretSauceText = "secret_sauce";
//		
//		String[] acceptedUsernamess = loginName.getLoginNameDetails(driver, By.xpath(userLoginPage.getLoginName()));
//		String[] passwordforallusers = loginName.getLoginNameDetails(driver, By.xpath(userLoginPage.getstandardPasswordlist()));
//		
//		Assert.assertEquals(acceptedUsernamesText, acceptedUsernamess[0], "Text Missmatched");
//		logger.info(acceptedUsernamess[0] + " Text is Present");
//		
//		Assert.assertEquals(standardUserText, acceptedUsernamess[1], "Text Missmatched");
//		logger.info(acceptedUsernamess[1] + " Text is Present");
//		
//		Assert.assertEquals(lockedOutUserText, acceptedUsernamess[2], "Text Missmatched");
//		logger.info(acceptedUsernamess[2] + " Text is Present");
//		
//		Assert.assertEquals(problemUserText, acceptedUsernamess[3], "Text Missmatched");
//		logger.info(acceptedUsernamess[3] + " Text is Present");
//		
//		Assert.assertEquals(performanceGlitchUserText, acceptedUsernamess[4], "Text Missmatched");
//		logger.info(acceptedUsernamess[4] + " Text is Present");
//			
//		Assert.assertEquals(passwordforallusersText, passwordforallusers[0], "Text Missmatched");
//		logger.info(passwordforallusers[0] + " Text is Present");
//		
//		Assert.assertEquals(secretSauceText, passwordforallusers[1], "Text Missmatched");
//		logger.info(passwordforallusers[1] + " Text is Present");
//	}
	
	@Test
	public void validLoginTest() {
		textFiledCheck.enterText(driver, By.xpath(userLoginPage.getUserName()), userLoginPage.getUserLabel(), userLoginPage.getStandardUserName());
		textFiledCheck.enterText(driver, By.xpath(userLoginPage.getPassword()), userLoginPage.getuserPasswordLabel(), userLoginPage.getStandardPassword());
		buttonCheck.loginButton(driver, By.xpath(userLoginPage.getLoginButton()), userLoginPage.getLoginLable());	
	}

	String sauceLabsBackpackTitleText = "Sauce Labs Backpack";
	String sauceLabsBackpackDiscriptionText = "carry.allTheThings() with the sleek, streamlined Sly Pack that melds uncompromising style with unequaled laptop and tablet protection.";
	String sauceLabsBackpackPriceText = "$29.99";


	@Test
	public void productVerification(){
		
		buttonCheck.loginButton(driver, By.xpath(productPage.getProductImage1()), productPage.getSauceLabsBackpackLabel());
		
		String sauceLabsBackpackTitleGetText = driver.findElement(By.xpath(productPage.getSauceLabsBackpackProductTitle())).getText();
		Assert.assertEquals(sauceLabsBackpackTitleText, sauceLabsBackpackTitleGetText, "Text NOT matched");
		logger.info(sauceLabsBackpackTitleGetText + " Text is Present");
		
		String sauceLabsBackpackDiscriptionGetText = driver.findElement(By.xpath(productPage.getSauceLabsBackpackProductDiscription())).getText();
		Assert.assertEquals(sauceLabsBackpackDiscriptionText, sauceLabsBackpackDiscriptionGetText, "Text NOT matched");
		logger.info(sauceLabsBackpackDiscriptionGetText + " Text is Present");
		
		String sauceLabsBackpackDiscriptionPriceText = driver.findElement(By.xpath(productPage.getSauceLabsBackpackProductPrice())).getText();
		Assert.assertEquals(sauceLabsBackpackPriceText, sauceLabsBackpackDiscriptionPriceText, "Text NOT matched");
		logger.info(sauceLabsBackpackDiscriptionPriceText + " Text is Present");
		
		buttonCheck.loginButton(driver, By.xpath(productPage.getSauceLabsBackpackProductAddToCart()), productPage.getSauceLabsBackpackLabel());
//		buttonCheck.loginButton(driver, By.xpath(productPage.getSauceLabsBackpackProductRemoveFromCart()), productPage.getRemoveFromCartLabel());
		buttonCheck.loginButton(driver, By.xpath(productPage.getproductBackButton()), productPage.getBackToProcductLabel());
		buttonCheck.loginButton(driver, By.xpath(productPage.getAddCartImage()), productPage.getcartImageLabel());
		
	}
	
	@Test
	public void verifyProductInCart(){
		String cartText = "YOUR CART";
		String cartQty = "QTY";
		String cartDes = "DESCRIPTION";
		
		
		String getHeaderText = driver.findElement(By.xpath(cartPage.getHeaderTextCart())).getText();
		Assert.assertEquals(cartText, getHeaderText, "Text NOT Matched");
		logger.info(getHeaderText + " Text is Present");
		
		String getQtyHeaderTextCart = driver.findElement(By.xpath(cartPage.getQtyHeaderText())).getText();
		Assert.assertEquals(cartQty, getQtyHeaderTextCart, "Text NOT Matched");
		logger.info(getQtyHeaderTextCart + " Text is Present");
		
		String getDiscriptioHeaderTextCart = driver.findElement(By.xpath(cartPage.getDiscriptioHeaderText())).getText();
		Assert.assertEquals(cartDes, getDiscriptioHeaderTextCart, "Text NOT Matched");
		logger.info(getDiscriptioHeaderTextCart + " Text is Present");
		
		String getSauceLabsBackpackCartLabelText = driver.findElement(By.xpath(cartPage.getSauceLabsBackpackCartLabel())).getText();
		Assert.assertEquals(sauceLabsBackpackTitleText, getSauceLabsBackpackCartLabelText, "Text NOT Matched");
		logger.info(getSauceLabsBackpackCartLabelText + " Text is Present");
		
		String getSauceLabsBackpackCartDiscriptionText = driver.findElement(By.xpath(cartPage.getSauceLabsBackpackCartDiscription())).getText();
		Assert.assertEquals(sauceLabsBackpackDiscriptionText, getSauceLabsBackpackCartDiscriptionText, "Text NOT Matched");
		logger.info(getSauceLabsBackpackCartDiscriptionText + "Text is Present");
		
		String getSauceLabsBackpackCartPriceText = driver.findElement(By.xpath(cartPage.getSauceLabsBackpackCartPrice())).getText();
		Assert.assertEquals(sauceLabsBackpackPriceText, getSauceLabsBackpackCartPriceText, "Text NOT Matched");
		logger.info(getSauceLabsBackpackCartPriceText + " Text is Present");
	
		buttonCheck.loginButton(driver, By.xpath(cartPage.getSauceLabsBackpackCartCheckout()), cartPage.getcheckoutCartLabel());
	}
	
	@Test
	public void checkOut() {
		
		String checkHeader = "CHECKOUT: YOUR INFORMATION";
		String fName = "Murali";
		String lName = "Mulla";
		String zip	= "632510";
		String continueButtonLabel = "Continue";
//		String cancelButtonLabel = "Cancel";
		
		String getCheckoutHeader = driver.findElement(By.xpath(checkout.getCheckoutHeader())).getText();
		Assert.assertEquals(checkHeader, getCheckoutHeader, "Text is NOT Matched");
		logger.info(getCheckoutHeader + " Text is Present");
		
		textFiledCheck.enterText(driver, By.xpath(checkout.getCheckoutFirstName()), checkout.getCheckoutFnameLabel(), fName);
		textFiledCheck.enterText(driver, By.xpath(checkout.checkoutLastName()), checkout.getcheckoutLnameLabel(), lName);
		textFiledCheck.enterText(driver, By.xpath(checkout.getcheckoutzip()), checkout.getcheckoutZipLabel(), zip);
		buttonCheck.productButton(driver, By.xpath(checkout.getcheckoutContinue()), continueButtonLabel);
//		buttonCheck.productButton(driver, By.xpath(checkout.getcheckoutCancel()), cancelButtonLabel);
	}
	@Test
	public void checkoutOverview() {
		String itemText = "Item total: ";
		String taxText = "Tax: ";
		String overviewText = "CHECKOUT: OVERVIEW";
		String payInfoText = "Payment Information:";
		String sauceCardText = "SauceCard #31337";
		String shippingText = "Shipping Information:";
		String deliveryText = "FREE PONY EXPRESS DELIVERY!";
		String checkoutFinishLabel = "Finish";
//		String checkoutCancelLabel = "Cancel";

		String getCheckoutOverviewTitle = driver.findElement(By.xpath(checkOverview.getCheckoutOverviewTitle()))
				.getText();
		Assert.assertEquals(overviewText, getCheckoutOverviewTitle, "Text is NOT Matched");
		logger.info(getCheckoutOverviewTitle + " Text is Present");

		String getCheckoutPaymentInfo = driver.findElement(By.xpath(checkOverview.getCheckoutPaymentInfo())).getText();
		Assert.assertEquals(payInfoText, getCheckoutPaymentInfo, "Text is NOT Matched");
		logger.info(getCheckoutPaymentInfo + " Text is Present");

		String getCheckoutSauceCard = driver.findElement(By.xpath(checkOverview.getCheckoutSauceCard())).getText();
		Assert.assertEquals(sauceCardText, getCheckoutSauceCard, "Text is NOT Matched");
		logger.info(getCheckoutSauceCard + " Text is Present");

		String getCheckoutShippingInfo = driver.findElement(By.xpath(checkOverview.getCheckoutShippingInfo()))
				.getText();
		Assert.assertEquals(shippingText, getCheckoutShippingInfo, "Text is NOT Matched");
		logger.info(getCheckoutShippingInfo + " Text is Present");

		String getCheckoutShippingDeliver = driver.findElement(By.xpath(checkOverview.getCheckoutShippingDeliver()))
				.getText();
		Assert.assertEquals(deliveryText, getCheckoutShippingDeliver, "Text is NOT Matched");
		logger.info(getCheckoutShippingDeliver + " Text is Present");

		String iteamTotalText = checkItemTotal.checkoutText(driver, By.xpath(checkOverview.getChcekoutItemTotal()));
		Assert.assertEquals(itemText, iteamTotalText, " Text is NOT Matched");
		logger.info(iteamTotalText + " Text is Present");

		String itemTaxText = checkItemTotal.checkoutText(driver, By.xpath(checkOverview.getCheckoutTax()));
		Assert.assertEquals(taxText, itemTaxText, " Text is NOT Matched");
		logger.info(itemTaxText + " Text is Present");

		double itemTotal = checkItemTotal.checkoutOverviewTotal(driver, By.xpath(checkOverview.getChcekoutItemTotal()));
		double tax = checkItemTotal.checkoutOverviewTotal(driver, By.xpath(checkOverview.getCheckoutTax()));
		double add = itemTotal + tax;
		logger.info("Total: " + add);
		
		double total = checkItemTotal.checkoutOverviewTotal(driver, By.xpath(checkOverview.getCheckoutTotal()));
		Assert.assertEquals(add, total, " Total is NOT Matched");
		logger.info(total + " Total is Matched");	

		buttonCheck.loginButton(driver, By.xpath(checkOverview.getCheckoutFinish()), checkoutFinishLabel);
//		buttonCheck.loginButton(driver, By.xpath(checkOverview.getCheckoutCancel()), checkoutCancelLabel);
	}
	
	@Test
	public void checkputComplete() {
		String completeText = "CHECKOUT: COMPLETE!";
		String thanksText = "THANK YOU FOR YOUR ORDER";
		String completeDiscriptionText = "Your order has been dispatched, and will arrive just as fast as the pony can get there!";
		String backHome = "Back Home";

		String getCheckoutCompleteText = driver.findElement(By.xpath(complete.getCheckoutComplete())).getText();
		Assert.assertEquals(completeText, getCheckoutCompleteText, " Text is NOT Matched");
		logger.info(getCheckoutCompleteText + " Text is Preasent");

		String getCompleteHeaderText = driver.findElement(By.xpath(complete.getCompleteHeaderText())).getText();
		Assert.assertEquals(thanksText, getCompleteHeaderText, " Text is NOT Matched");
		logger.info(getCompleteHeaderText + "Text is Present");

		String getOrderDiscription = driver.findElement(By.xpath(complete.getOrderDiscription())).getText();
		Assert.assertEquals(completeDiscriptionText, getOrderDiscription, " Text is NOT Matched");
		logger.info(getOrderDiscription + "Text is Present");

		elementCheck.isElementPresent(driver, By.xpath(complete.getponnyExpressLogo()), complete.getPonyExpressLogoLabel());

		buttonCheck.loginButton(driver, By.xpath(complete.getBackHomeButton()), backHome);

	
	}
	
	
	@AfterTest
	public void closeDriver() {
		requestDriver.closeBrowser(driver);
	}

}

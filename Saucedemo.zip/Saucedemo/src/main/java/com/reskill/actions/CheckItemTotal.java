package com.reskill.actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckItemTotal {

	
	public double getPrice(WebDriver driver, By locator) {
	String value = driver.findElement(locator).getText();
		String[] splitValue = value.split("\\$");
		String itemTotal = splitValue[1];
		double parseDouble = Double.parseDouble(itemTotal);
		return parseDouble;
	}
	
	public String getString(WebDriver driver, By locator) {
		String text = driver.findElement(locator).getText();
		String[] splitText = text.split("\\$");
		String itemTotalText = splitText[0];
		return itemTotalText;
}
	
	public double checkoutOverviewTotal(WebDriver driver, By locator) {
		double itemTotal = getPrice(driver, locator);
		return itemTotal;
	}
	
	public String checkoutText(WebDriver driver, By locator) {
		String itemTotalText = getString(driver, locator);
		return itemTotalText;
	}

//	public void name() {
//		Double price = loginName.getPrice(driver, By.xpath("//div[@class='summary_subtotal_label']"));
//		logger.info("Item Total Value: "+price);
//		Double taxValue = loginName.getPrice(driver, By.xpath("//div[@class='summary_tax_label']"));
//		logger.info("Tax Value: "+ taxValue);
//		double addition = price + taxValue;
//		logger.info("Total Value is:- "+addition);
//	}
}

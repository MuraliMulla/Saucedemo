package com.reskill.actions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDataReads {
		public void readExcelData() {
			File src = new File("src/main/java/com/reskill/testdata/SauceDemo_TestData.xlsx");
			FileInputStream files;
			try {
				files = new FileInputStream(src);
				XSSFWorkbook sheet;
				try {
					sheet = new XSSFWorkbook(files);
					XSSFSheet sheetData = sheet.getSheetAt(0);
					String firstEntry = sheetData.getRow(3).getCell(1).getStringCellValue();
					System.out.println("My Excel output: " + firstEntry);
				} catch (IOException e) {
					System.out.println("IO Execption");
				}
				
			} catch (FileNotFoundException e) {
				System.out.println("File Not Found Exeception");
			}
		}
		
		
		public static void main(String[] args){
			ExcelDataReads run = new ExcelDataReads();
			run.readExcelData();
		}
		
		}
	
	
  
	

